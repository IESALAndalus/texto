# COMANDOS DE GIT EN CONSOLA:

### 1º Configuración y primeros pasos:

**git init &lt;nombre\_proyecto&gt;:** Inicia un repositorio local con el nombre.

**git init** : Dentro de la carpeta del proyecto, inicia un repositorio en esta carpeta.

**git clone &lt;url&gt;** : Clona el repositiorio que haya en la url.

**git config --global user.name &quot;Nombre Usuario&quot;**

**git config --global user.email &quot;Email Usuario&quot;**

**git config --global credential.helper 'cache --timeout=3600'**: Recuerda usuario y contraseña temporalmente, en este caso una hora

**git config --global credential.helper cache**: Recuerda usuario y contraseña durante un tiempo default de 15 min.


### 2º Trabajo con repositorios:

**git status** : Hace un listado de los archivos nuevos o a insertar en un commit.

**git add &lt;nombre de archivo&gt;** : Añade al stagin area (o comienza el seguimiento)

**git add .** : Añade TODOS los archivos al stagin area (o comienza el seguimiento)

**git reset &lt;archivo&gt;** : Saca de stagin area el archivo, poniendo -- . saca todos.

**git commit -m &quot;Comentario de commit&quot;** : Realiza un commit. Guarda una copia del estado del archivo/s en ese momento y añade el código SHA a la cabecera del repositiorio.

**Deshacer un comit**:

**git reset --soft HEAD~1** : Deshace el último commit, pero deja los cambios en local, fuera de stagin área.

**git reset --hard HEAD~1** : Deshace el último commit y elimina los cambios realizados

**git checkout -- &lt;nombre\_archivo&gt;** :elimina los cambios en el archivo. Si se pone &#39;git checkout -- .&#39; se pierden TODOS los cambios y no se pueden recuperar por ningún medio.





### 3º Trabajo con ramas:

**git checkout -b &lt;nombre\_de\_rama&gt;:** Crea una nueva rama en el repositorio, con los archivos en el _estado en el que se encuentran en el momento que se crea y desde la rama en la que se crea_ y nos coloca en esa rama.

**git branch &lt;nombre\_de\_rama&gt;** : Crea una rama a partir de donde estamos y con el estado de los archivos en el que nos encontramos pero no nos lleva a ella.

**git checkout &lt;nobmre\_de\_rama&gt;** :  Nos lleva a la rama que mencionamos, no se puede hacer un cambio de rama si tenemos archivos en la rama que nos encontramos sin un commit, puesto que el cambio de rama haría que se perdiesen.

**git branch -d &lt;nombre\_de\_rama&gt;**  Eliminar una rama en local.

En el caso de que esa rama contenga trabajos sin fusionar, el comando anterior nos devolverá el siguiente error:

```
error: The branch 'nombre-rama' is not an ancestor of your current HEAD.
If you are sure you want to delete it, run 'git branch -D nombre-rama'.
```
**git branch -D &lt;nombre\_de\_rama&gt;**: Fuerza la eliminación de la rama mencionada.


En el caso de querer eliminar una rama del repositorio remoto, la sintaxis será la siguiente:

**git push origin :nombre-rama:** De esta forma, desaparecerá la rama nombre-rama del servidor.


### 4º Sincronización:

**git fetch** : Descarga el historial del repo remoto.

**git merge &lt;nombre\_de\_rama&gt;** : Trae los cambios de la rama mencionada a la rama en la que nos encontramos.

**git pull** : Baja el historial del repo remoto e incorpora los cambios. Es necesario hacer esto antes de subir nada.

**git push &lt;nombre\_de\_rama&gt;** : Sube los commits que tengamos en la rama local a la rama con ese nombre del repositorio remoto. Puede ser necesaria la palabra origin.


### Errores:

**git pull origin master --allow-unrelated-histories**: Cuando has creado un repo remoto y añadido el remoto en local pero no has clonado,  y lanza un error al hacer pull
